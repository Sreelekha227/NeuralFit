import cv2
import mediapipe as mp
import numpy as np

# Initialize MediaPipe Pose
mp_pose = mp.solutions.pose
pose = mp_pose.Pose()
mp_drawing = mp.solutions.drawing_utils

# Initialize Counter and State
counter = 0
is_lunging = False
THRESHOLD = 0.02  # Allowable margin for knee and toes position

# Function to calculate vertical distance
def vertical_distance(p1, p2):
    return abs(p1[1] - p2[1])

# Start Video Capture
cap = cv2.VideoCapture(0)
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    
    # Convert frame to RGB
    image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    image.flags.writeable = False
    results = pose.process(image)
    image.flags.writeable = True
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    
    if results.pose_landmarks:
        landmarks = results.pose_landmarks.landmark
        
        # Extract key landmarks
        left_ankle = (landmarks[mp_pose.PoseLandmark.LEFT_ANKLE].x, landmarks[mp_pose.PoseLandmark.LEFT_ANKLE].y)
        right_ankle = (landmarks[mp_pose.PoseLandmark.RIGHT_ANKLE].x, landmarks[mp_pose.PoseLandmark.RIGHT_ANKLE].y)
        left_knee = (landmarks[mp_pose.PoseLandmark.LEFT_KNEE].x, landmarks[mp_pose.PoseLandmark.LEFT_KNEE].y)
        right_knee = (landmarks[mp_pose.PoseLandmark.RIGHT_KNEE].x, landmarks[mp_pose.PoseLandmark.RIGHT_KNEE].y)
        left_hip = (landmarks[mp_pose.PoseLandmark.LEFT_HIP].x, landmarks[mp_pose.PoseLandmark.LEFT_HIP].y)
        right_hip = (landmarks[mp_pose.PoseLandmark.RIGHT_HIP].x, landmarks[mp_pose.PoseLandmark.RIGHT_HIP].y)
        
        # Detect which leg is leading based on x-coordinates (since the user is side-facing the camera)
        if left_ankle[0] < right_ankle[0]:  # Left leg is forward
            leading_knee, leading_ankle, trailing_knee = left_knee, left_ankle, right_knee
        else:  # Right leg is forward
            leading_knee, leading_ankle, trailing_knee = right_knee, right_ankle, left_knee
        
        # Check for proper lunge form with threshold adjustment
        knee_below_ankle = leading_knee[1] > (leading_ankle[1] - THRESHOLD)
        trailing_knee_not_over_toes = trailing_knee[1] > (leading_ankle[1] - THRESHOLD)
        
        if knee_below_ankle and trailing_knee_not_over_toes and not is_lunging:
            is_lunging = True  # Lunge detected
            
        elif not knee_below_ankle and is_lunging:
            counter += 1  # Count rep when returning to standing
            is_lunging = False
        
        # Display Counter
        cv2.putText(image, f'Forward Lunges: {counter}', (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        # Draw Landmarks
        mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)
    
    # Show Frame
    cv2.imshow('Forward Lunge Detector', image)
    if cv2.waitKey(10) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

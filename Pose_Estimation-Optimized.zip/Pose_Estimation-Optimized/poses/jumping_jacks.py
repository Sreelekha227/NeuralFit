import cv2
import mediapipe as mp
import numpy as np

# Initialize MediaPipe Pose
mp_pose = mp.solutions.pose
pose = mp_pose.Pose()
mp_drawing = mp.solutions.drawing_utils

# Function to calculate Euclidean distance
def calculate_distance(p1, p2):
    return np.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)

# Jumping Jack Counter
counter = 0
is_open = False

# Start Video Capture
cap = cv2.VideoCapture(0)
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    
    # Convert frame to RGB
    image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    image.flags.writeable = False
    results = pose.process(image)
    image.flags.writeable = True
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    
    if results.pose_landmarks:
        landmarks = results.pose_landmarks.landmark
        
        # Extract relevant landmarks
        shoulder_l = (landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER].x, landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER].y)
        shoulder_r = (landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER].x, landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER].y)
        wrist_l = (landmarks[mp_pose.PoseLandmark.LEFT_WRIST].x, landmarks[mp_pose.PoseLandmark.LEFT_WRIST].y)
        wrist_r = (landmarks[mp_pose.PoseLandmark.RIGHT_WRIST].x, landmarks[mp_pose.PoseLandmark.RIGHT_WRIST].y)
        hip_l = (landmarks[mp_pose.PoseLandmark.LEFT_HIP].x, landmarks[mp_pose.PoseLandmark.LEFT_HIP].y)
        hip_r = (landmarks[mp_pose.PoseLandmark.RIGHT_HIP].x, landmarks[mp_pose.PoseLandmark.RIGHT_HIP].y)
        toe_l = (landmarks[mp_pose.PoseLandmark.LEFT_FOOT_INDEX].x, landmarks[mp_pose.PoseLandmark.LEFT_FOOT_INDEX].y)
        toe_r = (landmarks[mp_pose.PoseLandmark.RIGHT_FOOT_INDEX].x, landmarks[mp_pose.PoseLandmark.RIGHT_FOOT_INDEX].y)
        
        # Calculate arm and leg lengths
        arm_length = calculate_distance(shoulder_l, wrist_l)
        leg_length = calculate_distance(hip_l, toe_l)
        
        # Attention Pose Detection
        arms_down = wrist_l[1] > shoulder_l[1] and wrist_r[1] > shoulder_r[1]
        feet_together = abs(toe_l[0] - toe_r[0]) < 0.1  # Small distance threshold
        
        # Jump Pose Detection
        arms_up = wrist_l[1] < shoulder_l[1] - 0.5 * arm_length and wrist_r[1] < shoulder_r[1] - 0.5 * arm_length
        feet_apart = 0.4 * leg_length < abs(toe_l[0] - toe_r[0]) < 0.6 * leg_length
        
        if arms_up and feet_apart and not is_open:
            is_open = True
        elif arms_down and feet_together and is_open:
            counter += 1
            is_open = False
        
        # Display Counter
        cv2.putText(image, f'Jumping Jacks: {counter}', (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        
        # Draw Landmarks
        mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)
    
    # Show Frame
    cv2.imshow('Jumping Jack Detector', image)
    if cv2.waitKey(10) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
